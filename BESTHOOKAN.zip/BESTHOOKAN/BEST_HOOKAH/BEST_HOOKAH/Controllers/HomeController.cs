﻿using BEST_HOOKAH.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace BEST_HOOKAH.Controllers
{
    public class HomeController : Controller
    {
        private ClientReserv clientReserv = new ClientReserv();
        private readonly ILogger<HomeController> _logger;
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
     
        
        
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Reservation()
        {
            clientReserv.CheckReserveRoom();
            return View();
        }

        [HttpPost]
        public IActionResult Reservation(ClientInfo model)
        {
            ReturnResult result = new ReturnResult();
            result = clientReserv.RoomReserv(model);
            TempData["ResultRegister"] = true;

            if (result.Result)
            {
                return View("Index");
            }
            else
            {
                return View("Reservation");
            }
        }
        public IActionResult ReservesRooms()
        {
            //List<ClientInfo> clients = clientReserv.ClientInfoView();


            //TempData["ClientInfoView"] = clientReserv.ClientInfoView();


            List<ClientInfo> clients = clientReserv.ClientInfoView();


            return View(clients);
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}