﻿using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;

namespace BEST_HOOKAH.Models
{
    public class ClientInfo
    {
        public int ClientId { get; set; }
        public int RoomId { get; set; }
        public string NameCL { get; set; }
        public DateTime DateOfSettlemes { get; set; }
        public DateTime DateOut { get; set; }
        public int RoomNumber { get; set; }
        public int Floor { get; set; }
        public int Rooms { get; set; }
        public bool Closed { get; set; }


    }

}
