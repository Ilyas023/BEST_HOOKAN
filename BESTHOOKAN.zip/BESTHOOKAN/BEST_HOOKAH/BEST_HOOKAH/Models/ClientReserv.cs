﻿using Dapper;
using System.Data.SqlClient;
using System.Transactions;

namespace BEST_HOOKAH.Models
{
    public class ClientReserv
    {
        string connectionString = @"Server=DESKTOP-Q6RQB80;Database=BestHookan;Trusted_Connection=True;";

        public bool CheckAvailability(int rooms, out string status, out RoomInfo clientRoom)
        {
            clientRoom = null;
            status = "Номер с таким колличеством комнат не доступен";
            bool result = false;
            try
            {
                using (SqlConnection db = new SqlConnection(connectionString))
                {
                    db.Open();

                    List<RoomInfo> room;

                    room = db.Query<RoomInfo>("SELECT * FROM Rooms where Rooms = @rooms",
                        new { Rooms = rooms }).ToList();

                    foreach (RoomInfo item in room)
                    {
                        if (item.Closed != true)
                        {
                            int roomId = item.RoomId;
                            clientRoom = db.QueryFirstOrDefault<RoomInfo>("SELECT * FROM Rooms where RoomId = @roomId",
                                new { RoomId = roomId });
                            status = "Номер с таким колличеством комнат доступен";
                            result = true;
                            break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                status = "При проверки доступности возникла ошибка (" + ex.Message + ")";
                clientRoom = null;
                result = false;
            }
            return result;
        }

        public bool CheckCorrectDate(DateTime DateOfSettlemes, DateTime DateOut)
        {
            if (DateOfSettlemes < DateOut && DateOfSettlemes > DateTime.Now)
            {
                return true;
            }
            return false;
        }

        public void CheckReserveRoom()
        {
            List<ClientInfo> clients = new List<ClientInfo>();
            try
            {
                using (SqlConnection db = new SqlConnection(connectionString))
                {
                    db.Open();

                    clients = db.Query<ClientInfo>("SELECT * FROM ClientBase").ToList();
                    foreach (ClientInfo client in clients)
                    {
                        if (client.DateOut <= DateTime.Now)
                        {
                            //Я не знаю как тут делать, в запросе он просто не принимает чистую запись true и
                            //выходит только вот так. Может это нужно сделать через LINQ?
                            client.Closed = false;
                            db.Query("UPDATE [dbo].[Rooms]" +
                            "SET [Closed] = @Closed" + " WHERE NumberRoom = @RoomNumber", client);

                            db.Query("DELETE [dbo].[ClientBase]" +
                            " WHERE ClientId = @ClientId", client);
                        }
                    }
                    
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Произошла ошибка: {ex.Message}");
            }
        }

        public ReturnResult RoomReserv(ClientInfo clientInfo)
        {
            ReturnResult result = new ReturnResult();

            if (CheckAvailability(clientInfo.Rooms, out string status, out RoomInfo clientRoom) 
                && CheckCorrectDate(clientInfo.DateOfSettlemes, clientInfo.DateOut))
            {
                clientInfo.Floor = clientRoom.Floor;
                clientInfo.RoomNumber = clientRoom.NumberRoom;
                clientInfo.Closed = true;
                clientInfo.RoomId = clientRoom.RoomId;
                try
                {
                    using (SqlConnection db = new SqlConnection(connectionString))
                    {
                        db.Open();

                        //МЕСТО ПРЕОДОЛЕНИЯ ОШИБКИ
                        db.Query("INSERT INTO [dbo].[ClientBase]" +
                            " ([NameCL],[DateOfSettlemes],[DateOut],[RoomNumber],[Floor],[Rooms])" +
                            "VALUES (@NameCL,@DateOfSettlemes,@DateOut,@RoomNumber,@Floor,@Rooms)", clientInfo);

                        db.Query("UPDATE [dbo].[Rooms]" +
                            "SET [Closed] = @Closed" + " WHERE RoomId = @RoomId", clientInfo);
                    }

                    result.Result = true;
                    result.Message = "Вы успешно сняли номер.";
                    Console.WriteLine($"Результат: {result.Result}");
                    Console.WriteLine($"Сообщение: {result.Message}");
                }
                catch (Exception ex)
                {
                    result.Result = false;
                    result.Message = ex.Message;
                    Console.WriteLine(ex.Message);
                }

            }
            else
            {
                result.Result = false;
                result.Message = "Извините, возникла ошибка, попробуйте еще раз";
                Console.WriteLine($"Результат: {result.Result}");
                Console.WriteLine($"Сообщение: {result.Message}");
                Console.WriteLine($"Сообщение: {clientInfo.DateOfSettlemes}");
                Console.WriteLine($"Сообщение: {clientInfo.DateOut}");
            }

            return result;
        }

        public List<ClientInfo> ClientInfoView()
        {
            List<ClientInfo> clients = new List<ClientInfo>();

            try
            {
                using (SqlConnection db = new SqlConnection(connectionString))
                {
                    db.Open();

                    clients = db.Query<ClientInfo>("SELECT * FROM ClientBase").ToList();
                }
            }
            catch (Exception ex)
            {
                Console.Write( ex.Message);
            }

            return clients;
        }
        
    }
}
