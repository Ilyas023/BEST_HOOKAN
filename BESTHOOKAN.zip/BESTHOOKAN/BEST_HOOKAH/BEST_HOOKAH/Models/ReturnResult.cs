﻿namespace BEST_HOOKAH.Models
{
    public class ReturnResult
    {
        public bool Result { get; set; }
        public string Message { get; set; }
    }
}
