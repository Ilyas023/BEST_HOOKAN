﻿namespace BEST_HOOKAH.Models
{
    public class RoomInfo
    {
        public int RoomId { get; set; }
        public int NumberRoom { get; set; }
        public int Rooms { get; set; }
        public int Floor { get; set; }
        public bool Closed { get; set; }
    }
}
